import MostTradedCheckTab from './MostTradedCheckTab/MostTradedCheckTab';

const MostTradedOnShare = () => {
  return (
    <div className="p-5">
      <section>
        <MostTradedCheckTab />
      </section>
    </div>
  );
};

export default MostTradedOnShare;
