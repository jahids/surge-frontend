// /* eslint-disable  */
// import React from 'react';
// import { truncateText } from '../../../Utils/converter';
// const defaultlogo = `https://images2.imgbox.com/52/06/7xFpAH04_o.png`;

// function SignleDetails({ logo, symbol }: any) {
//   return (
//     <>
//       <div>
//         <img
//           className="w-12  h-12  p-1 rounded-full bg-gray-100 object-contain"
//           src={logo || defaultlogo}
//           alt=""
//         />
//       </div>
//       <div className="mx-5">
//         <p className="font-bold">{symbol}</p>
//         {/* <p className="text-gray-400 text-sm">{truncateText(data?.name, 15)}</p> */}
//       </div>
//     </>
//   );
// }

// export default SignleDetails;
