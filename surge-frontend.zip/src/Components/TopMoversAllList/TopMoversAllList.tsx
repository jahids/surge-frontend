import TopMoversTab from './TopMoversTab/TopMoversTab';

const TopMoversAllList = () => {
  return (
    <div className="p-5">
      <section>
        <TopMoversTab />
      </section>
    </div>
  );
};

export default TopMoversAllList;
