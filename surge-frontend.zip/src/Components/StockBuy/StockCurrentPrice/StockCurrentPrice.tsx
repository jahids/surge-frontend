const StockCurrentPrice = () => {
  return (
    <div className="mt-6">
      <p className="text-xl font-bold">Current Price</p>
    </div>
  );
};

export default StockCurrentPrice;
