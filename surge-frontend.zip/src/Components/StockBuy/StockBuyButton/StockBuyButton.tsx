const StockBuyButton = () => {
  return (
    <div>
      <button className="bg-indigo-600 px-14 py-3 text-white rounded-full">
        Buy
      </button>
    </div>
  );
};

export default StockBuyButton;
