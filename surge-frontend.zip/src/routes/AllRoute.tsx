// const allRoute = [
//   {
//     path: '/',
//     component: MainDash,
//     roles: ['admin', 'user'],
//   },
//   {
//     path: '/entryform',
//     component: EntryForm,
//     roles: ['admin', 'user'],
//   },
//   {
//     path: '/profile',
//     component: ProfilePage,
//     roles: ['admin', 'user'],
//   },

//   {
//     path: '/advchart',
//     component: PredectionChart,
//     roles: ['admin', 'user'],
//   },
//   {
//     path: '/right',
//     component: RightSide,
//     roles: ['admin', 'user'],
//   },
//   // Add more admin routes as needed
// ];
