import TopMoversAllList from '../../Components/TopMoversAllList/TopMoversAllList';

const TopMoversPage = () => {
  return (
    <div>
      <TopMoversAllList />
    </div>
  );
};

export default TopMoversPage;
