import AllAssets from '../../Components/AllAssets/AllAssets';

const AllAssetsPage = () => {
  return (
    <div>
      <AllAssets />
    </div>
  );
};

export default AllAssetsPage;
