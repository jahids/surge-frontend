import MostTradedOnShareList from '../../Components/MostTradedOnShareList/MostTradedOnShareList';

const MostTradedOnSharesPage = () => {
  return (
    <div>
      <MostTradedOnShareList />
    </div>
  );
};

export default MostTradedOnSharesPage;
