/* eslint-disable import/no-named-as-default-member */

import LoginFrom from '../../Components/LoginForm/LoginFrom';

const LoginPage = () => {
  return (
    <div>
      <LoginFrom />
    </div>
  );
};

export default LoginPage;
