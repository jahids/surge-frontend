import AllStockLists from "../../Components/AllStockLists/AllStockLists";

const AllStockPage = () => {
  return (
    <div>
      <AllStockLists/>
    </div>
  );
};

export default AllStockPage;
