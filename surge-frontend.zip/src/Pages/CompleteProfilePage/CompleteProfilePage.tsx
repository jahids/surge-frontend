import CompleteProfile from '../../Components/CompleteProfile/CompleteProfileContainer';

const CompleteProfilePage = () => {
  return (
    <div>
      <CompleteProfile />
    </div>
  );
};

export default CompleteProfilePage;
