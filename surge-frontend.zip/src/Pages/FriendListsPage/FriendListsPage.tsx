import FriendListsContainer from '../../Components/FriendLists/FriendListsContainer';

const FriendListsPage = () => {
  return (
    <div>
      <FriendListsContainer />
    </div>
  );
};

export default FriendListsPage;
