import NotificationsContainer from '../../Components/Notifications/NotificationsContainer';

const NotificationPage = () => {
  return (
    <div>
      <NotificationsContainer />
    </div>
  );
};

export default NotificationPage;
