import StockBuyContainer from '../../Components/StockBuy/StockBuyContainer';

const StockBuyPage = () => {
  return (
    <div>
      <StockBuyContainer />
    </div>
  );
};

export default StockBuyPage;
