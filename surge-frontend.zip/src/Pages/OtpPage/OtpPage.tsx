import Otp from '../../Components/Otp/Otp';

const OtpPage = () => {
  return (
    <div>
      <Otp />
    </div>
  );
};

export default OtpPage;
