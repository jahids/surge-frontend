import RegistrationFrom from '../../Components/RegistrationFrom/RegistrationFrom';

const RegistrationPage = () => {
  return (
    <div>
      <RegistrationFrom />
    </div>
  );
};

export default RegistrationPage;
