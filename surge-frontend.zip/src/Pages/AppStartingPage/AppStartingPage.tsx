import AppStarting from '../../Components/AppStarting/AppStarting';

const AppStartingPage = () => {
  return (
    <>
      <AppStarting />
    </>
  );
};

export default AppStartingPage;
